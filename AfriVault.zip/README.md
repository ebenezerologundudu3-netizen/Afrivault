# AfriVault

Starter full-stack project.
